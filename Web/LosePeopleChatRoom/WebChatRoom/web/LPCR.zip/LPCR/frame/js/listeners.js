// import VueTagTextarea from 'vue-tag-textarea'
// import 'vue-tag-textarea/lib/vue-tag-textarea.css'
// Vue.use(VueTagTextarea)

// export default {
    // data () {
      // return {
        // text: 'demo'
      // }
    // }
  // }

// var textarea={
  // 'shift': false,
  // 'enable' : false,
  // 'ctrl' : false
// }


 

